"""Conversão de resultados do PyNite para entidades do domínio."""

import numpy as np

from osa.domain import AnalysisResult


class ResultMapper:
    def map(self, source, model_revision: int, load_reference: str) -> AnalysisResult:
        node_results = {}
        for name, node in source.nodes.items():
            node_results[name] = {
                "DX": float(node.DX[load_reference]), "DY": float(node.DY[load_reference]),
                "DZ": float(node.DZ[load_reference]), "RX": float(node.RX[load_reference]),
                "RY": float(node.RY[load_reference]), "RZ": float(node.RZ[load_reference]),
                "RXN_FX": float(node.RxnFX[load_reference]), "RXN_FY": float(node.RxnFY[load_reference]),
                "RXN_FZ": float(node.RxnFZ[load_reference]), "RXN_MX": float(node.RxnMX[load_reference]),
                "RXN_MY": float(node.RxnMY[load_reference]), "RXN_MZ": float(node.RxnMZ[load_reference]),
            }
        member_results = {}
        for name, member in source.members.items():
            length = member.L()
            positions = np.linspace(0.0, length, 21)
            samples = [
                self._member_sample(member, float(position), load_reference)
                for position in positions
            ]
            # The first and last samples are exactly the member endpoints.
            # Reusing them avoids querying PyNite for the same nine result
            # components a second time for every member and combination.
            start = {key: value for key, value in samples[0].items() if key != "x"}
            end = {key: value for key, value in samples[-1].items() if key != "x"}
            member_results[name] = {
                "length": float(length),
                "start": start,
                "end": end,
                "samples": samples,
            }
        return AnalysisResult(model_revision, load_reference, node_results, member_results)

    @staticmethod
    def _member_end_result(member, position: float, load_reference: str) -> dict[str, float]:
        deflections = ResultMapper._global_deflections(member, position, load_reference)
        return {
            "axial": float(member.axial(position, load_reference)),
            "shear_y": float(member.shear("Fy", position, load_reference)),
            "shear_z": float(member.shear("Fz", position, load_reference)),
            "moment_y": float(member.moment("My", position, load_reference)),
            "moment_z": float(member.moment("Mz", position, load_reference)),
            "torque": float(member.torque(position, load_reference)),
            **deflections,
        }

    @staticmethod
    def _member_sample(member, position: float, load_reference: str) -> dict[str, float]:
        deflections = ResultMapper._global_deflections(member, position, load_reference)
        return {
            "x": position,
            "axial": float(member.axial(position, load_reference)),
            "shear_y": float(member.shear("Fy", position, load_reference)),
            "shear_z": float(member.shear("Fz", position, load_reference)),
            "moment_y": float(member.moment("My", position, load_reference)),
            "moment_z": float(member.moment("Mz", position, load_reference)),
            "torque": float(member.torque(position, load_reference)),
            **deflections,
        }

    @staticmethod
    def _global_deflections(member, position: float, load_reference: str) -> dict[str, float]:
        """Return the member displacement components in global XYZ axes.

        PyNite's member ``deflection`` API returns local x/y/z components.
        Its transformation matrix maps global vectors to local vectors, so
        the transpose maps the sampled local displacement back to global XYZ.
        """
        local = np.array((
            member.deflection("dx", position, load_reference),
            member.deflection("dy", position, load_reference),
            member.deflection("dz", position, load_reference),
        ), dtype=float)
        local_from_global = np.asarray(member.T()[:3, :3], dtype=float)
        global_displacement = local_from_global.T @ local
        return {
            "deflection_x": float(global_displacement[0]),
            "deflection_y": float(global_displacement[1]),
            "deflection_z": float(global_displacement[2]),
        }
