import math
from dataclasses import replace

from osa.domain import (
    Action,
    ActionDefinition,
    ActionGroup,
    LoadCase,
    LoadCombination,
    StructuralModel,
)

ACTION_GROUP_TEMPLATES = {
    "PP+AP+AV": ActionGroup(
        "PP+AP+AV",
        (ActionDefinition("Peso próprio", "PP"), ActionDefinition("Ação permanente", "AP"), ActionDefinition("Ação variável", "AV")),
    ),
    "PP+AP+AV+4V": ActionGroup(
        "PP+AP+AV+4V",
        (
            ActionDefinition("Peso próprio", "PP"), ActionDefinition("Ação permanente", "AP"), ActionDefinition("Ação variável", "AV"),
            ActionDefinition("Vento 0°", "V0"), ActionDefinition("Vento 90°", "V90"),
            ActionDefinition("Vento 180°", "V180"), ActionDefinition("Vento 270°", "V270"),
        ),
    ),
}


def _template_group(template: ActionGroup) -> ActionGroup:
    return ActionGroup(template.name, tuple(template.actions))


class ActionService:
    def __init__(self, model: StructuralModel) -> None:
        self.model = model

    def add_action(self, action: Action) -> Action:
        """Cria ou substitui uma ação do mesmo tipo, alvo e ação ativa."""
        existing = next(
            (
                candidate for candidate in self.model.actions.values()
                if (
                    candidate.kind == action.kind
                    and candidate.target == action.target
                    and candidate.load_case == action.load_case
                )
            ),
            None,
        )
        if existing is not None:
            action = Action(existing.name, action.kind, action.target, action.components, action.load_case)
        elif action.name in self.model.actions:
            raise ValueError(f"Já existe uma ação chamada '{action.name}'.")
        self.model.actions[action.name] = action
        self.model._touch()
        return action

    def remove_action(self, name: str) -> Action:
        """Remove uma ação individual e retorna a ação removida."""
        action = self.model.actions.pop(name, None)
        if action is None:
            raise ValueError(f"Ação '{name}' não encontrada.")
        self.model._touch()
        return action

    def update_action(self, name: str, **changes: object) -> Action:
        """Atualiza uma ação aplicada preservando seu identificador automático."""
        current = self.model.actions.get(name)
        if current is None:
            raise ValueError(f"Ação '{name}' não encontrada.")
        updated = replace(current, **changes)
        conflict = next(
            (
                candidate for candidate_name, candidate in self.model.actions.items()
                if candidate_name != name
                and candidate.kind == updated.kind
                and candidate.target == updated.target
                and candidate.load_case == updated.load_case
            ),
            None,
        )
        if conflict is not None:
            raise ValueError(
                "Já existe uma ação equivalente para esse alvo, direção e caso de carregamento: "
                f"'{conflict.name}'."
            )
        self.model.actions[name] = updated
        self.model._touch()
        return updated

    def remove_actions(
        self,
        *,
        target: str | None = None,
        targets: tuple[str, ...] | None = None,
        load_case: str | None = None,
    ) -> tuple[str, ...]:
        """Remove ações filtradas por um ou vários alvos e/ou caso de carregamento."""
        target_filter = None
        if target is not None:
            target_filter = {target}
        elif targets:
            target_filter = set(targets)
        names = tuple(
            name for name, action in self.model.actions.items()
            if (target_filter is None or action.target in target_filter)
            and (load_case is None or action.load_case == load_case)
        )
        if names:
            for name in names:
                del self.model.actions[name]
            self.model._touch()
        return names

    def action_group_names(self) -> tuple[str, ...]:
        """Retorna grupos personalizados e modelos disponíveis."""
        return tuple(dict.fromkeys((*self.model.action_groups, *self.templates())))

    def add_member_distributed_force(
        self, target: str, direction: str, initial: float, final: float, load_case: str,
        reference: str = "global",
    ) -> Action:
        normalized_reference = reference.casefold()
        if normalized_reference not in {"global", "local"}:
            raise ValueError("O sistema de direção deve ser Global ou Local.")
        if normalized_reference == "global" and direction.upper() == "Z":
            self._remove_member_action(target, "member_distributed_force_selfweight_Z", load_case)
        suffix = f"{normalized_reference}_" if normalized_reference == "local" else ""
        kind = f"member_distributed_force_{suffix}{direction.upper()}"
        index = 1
        while f"Carga {index}" in self.model.actions:
            index += 1
        action = Action(
            f"Carga {index}", kind, target,
            (float(initial), float(final)), load_case,
        )
        return self.add_action(action)

    def add_member_selfweight(self, target: str, value: float, load_case: str) -> Action:
        self._remove_member_action(target, "member_distributed_force_Z", load_case)
        self._remove_member_action(target, "member_distributed_force_global_Z", load_case)
        index = 1
        while f"Carga {index}" in self.model.actions:
            index += 1
        return self.add_action(Action(
            f"Carga {index}", "member_distributed_force_selfweight_Z", target,
            (float(value), float(value)), load_case,
        ))

    def replace_action_with_selfweight(
        self, load_case: str, weights: tuple[tuple[str, float], ...],
    ) -> tuple[Action, ...]:
        """Apaga todas as cargas da ação e recria somente os pesos próprios."""
        for name, action in tuple(self.model.actions.items()):
            if action.load_case == load_case:
                del self.model.actions[name]
        created: list[Action] = []
        for target, value in weights:
            index = 1
            while f"Carga {index}" in self.model.actions:
                index += 1
            action = Action(
                f"Carga {index}", "member_distributed_force_selfweight_Z", target,
                (float(value), float(value)), load_case,
            )
            self.model.actions[action.name] = action
            created.append(action)
        self.model._touch()
        return tuple(created)

    def has_selfweight(self, load_case: str) -> bool:
        return any(
            action.load_case == load_case
            and action.kind == "member_distributed_force_selfweight_Z"
            for action in self.model.actions.values()
        )

    def selfweight_load_cases(self) -> set[str]:
        """Retorna as ações que estão restritas ao peso próprio."""
        return {
            action.load_case
            for action in self.model.actions.values()
            if action.kind == "member_distributed_force_selfweight_Z"
        }

    def remove_selfweight(self, load_case: str) -> None:
        names = [
            name for name, action in self.model.actions.items()
            if action.load_case == load_case
            and action.kind == "member_distributed_force_selfweight_Z"
        ]
        if not names:
            return
        for name in names:
            del self.model.actions[name]
        self.model._touch()

    def _remove_member_action(self, target: str, kind: str, load_case: str) -> None:
        for name, action in tuple(self.model.actions.items()):
            if action.target == target and action.kind == kind and action.load_case == load_case:
                del self.model.actions[name]

    def add_member_moment(self, target: str, direction: str, value: float, load_case: str) -> Action:
        index = 1
        while f"Carga {index}" in self.model.actions:
            index += 1
        return self.add_action(Action(
            f"Carga {index}", f"member_moment_{direction.upper()}", target, (float(value),), load_case,
        ))

    def add_node_force(self, target: str, direction: str, value: float, load_case: str) -> Action | None:
        kind = f"node_force_{direction.upper()}"
        if math.isclose(value, 0.0, abs_tol=1e-12):
            self._remove_actions(target, kind, load_case)
            return None
        index = 1
        while f"Carga {index}" in self.model.actions:
            index += 1
        return self.add_action(Action(
            f"Carga {index}", kind, target, (float(value),), load_case,
        ))

    def add_node_moment(self, target: str, direction: str, value: float, load_case: str) -> Action | None:
        kind = f"node_moment_{direction.upper()}"
        if math.isclose(value, 0.0, abs_tol=1e-12):
            self._remove_actions(target, kind, load_case)
            return None
        index = 1
        while f"Carga {index}" in self.model.actions:
            index += 1
        return self.add_action(Action(
            f"Carga {index}", kind, target, (float(value),), load_case,
        ))

    def _remove_actions(self, target: str, kind: str, load_case: str) -> None:
        names = [
            name for name, action in self.model.actions.items()
            if action.target == target and action.kind == kind and action.load_case == load_case
        ]
        if not names:
            return
        for name in names:
            del self.model.actions[name]
        self.model._touch()

    @staticmethod
    def templates() -> dict[str, ActionGroup]:
        return {name: _template_group(group) for name, group in ACTION_GROUP_TEMPLATES.items()}

    def selected_group(self) -> ActionGroup | None:
        """Retorna o grupo ativo, incluindo os templates ainda não salvos."""
        name = self.model.selected_action_group
        return self.model.action_groups.get(name) or self.templates().get(name)

    def add_action_group(self, group: ActionGroup) -> ActionGroup:
        return self.model.add_action_group(group)

    def select_action_group(self, name: str) -> None:
        self.model.set_selected_action_group(name)

    def set_action_group_alias(self, template_name: str, group_name: str) -> None:
        self.model.set_action_group_alias(template_name, group_name)

    def update_action_group(self, old_name: str, group: ActionGroup) -> ActionGroup:
        return self.model.update_action_group(old_name, group)

    def remove_action_group(self, name: str) -> None:
        self.model.remove_action_group(name)

    def set_load_case(self, load_case: LoadCase) -> None:
        self.model.load_cases[load_case.name] = load_case
        self.model._touch()

    def set_combination(self, combination: LoadCombination) -> None:
        self.model.load_combinations[combination.name] = combination
        self.model._touch()

    def remove_combination(self, name: str) -> None:
        if name in self.model.load_combinations:
            del self.model.load_combinations[name]
            self.model._touch()

    def ensure_default_combinations(self) -> bool:
        """Create the standard combinations for the default action group once."""
        group = self.selected_group()
        group_name = "PP+AP+AV"
        if group is None or group.name != group_name or group_name in self.model.combination_groups_initialized:
            return False
        self.model.combination_groups_initialized.add(group_name)
        if any(
            combination.action_group in (None, group_name)
            for combination in self.model.load_combinations.values()
        ):
            self.model._touch()
            return False
        abbreviations = tuple(action.abbreviation for action in group.actions)
        if abbreviations != ("PP", "AP", "AV"):
            self.model._touch()
            return False
        all_active = abbreviations
        ones = tuple((abbreviation, 1.0) for abbreviation in abbreviations)
        for combination in (
            LoadCombination("Combinação 01", ones, ones, ones, all_active, group_name, "CAR"),
            LoadCombination(
                "Combinação 02",
                (("PP", 1.25), ("AP", 1.35), ("AV", 1.50)), ones, ones,
                all_active, group_name, "ELU",
            ),
            LoadCombination(
                "Combinação 03", ones, ones,
                (("PP", 1.0), ("AP", 1.0), ("AV", 0.60)), all_active, group_name, "ELS",
            ),
        ):
            self.set_combination(combination)
        return True
