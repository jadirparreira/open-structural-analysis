"""Ícones SVG da interface."""
