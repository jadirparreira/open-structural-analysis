"""Entidades puras do domínio estrutural.

Este módulo não depende de Qt, VTK, PyVista ou PyNite.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class Support:
    dx: bool = False
    dy: bool = False
    dz: bool = False
    rx: bool = False
    ry: bool = False
    rz: bool = False

    @classmethod
    def from_tuple(cls, values: tuple[bool, ...]) -> Support:
        if len(values) != 6:
            raise ValueError("Uma restrição deve possuir seis graus de liberdade.")
        return cls(*(bool(value) for value in values))

    def as_tuple(self) -> tuple[bool, bool, bool, bool, bool, bool]:
        return self.dx, self.dy, self.dz, self.rx, self.ry, self.rz


@dataclass(frozen=True, slots=True)
class Node:
    name: str
    x: float
    y: float
    z: float
    supports: tuple[bool, bool, bool, bool, bool, bool] = (False,) * 6
    # Translational stiffnesses use kN/m; rotational stiffnesses use kN·m/rad.
    support_stiffness: tuple[float, float, float, float, float, float] = (0.0,) * 6

    @property
    def support(self) -> Support:
        return Support.from_tuple(self.supports)


@dataclass(frozen=True, slots=True)
class ReferenceAxis:
    """A named reference line at a value on its global coordinate axis."""

    label: str
    value: float


@dataclass(frozen=True, slots=True)
class Member:
    name: str
    start_node: str
    end_node: str
    material: str = "Indefinido"
    material_values: tuple[float, float, float, float] = (200000000.0, 76900000.0, 0.30, 76.9822025)
    section: str = ""
    profile: str = ""
    section_geometry: tuple[tuple[str, float], ...] = ()
    # Espelhamento visual e geométrico da seção em torno do eixo local Z.
    section_mirrored: bool = False
    rotation: int = 0
    releases: tuple[bool, ...] = (False,) * 12
    color: str = "#6e7781"
    # Distâncias visuais, em metros, entre os nós analíticos e as faces
    # sólidas nas extremidades A e B. Não participam do modelo do solver.
    solid_face_offsets: tuple[float, float] = (0.0, 0.0)
    # Deslocamento visual da seção sólida no plano local Y/Z. Não participa
    # do modelo analítico nem altera a posição dos nós do membro.
    solid_section_offsets: tuple[float, float] = (0.0, 0.0)
    # Percentuais de flexibilização das rotações locais Rxa/Rxb, Rya/Ryb e
    # Rza/Rzb. Zero indica vínculo rígido; de 1% a 99% reduz a rigidez efetiva
    # por uma mola rotacional equivalente; 100% libera a rotação.
    rotation_flexibility_percent: tuple[int, int, int, int, int, int] = (0,) * 6

    def geometry_dict(self) -> dict[str, float]:
        return dict(self.section_geometry)


@dataclass(frozen=True, slots=True)
class RigidBar:
    """Idealized rigid connection between two existing nodes."""

    name: str
    start_node: str
    end_node: str


# Compatibilidade pública com o nome utilizado até agora.
Bar = Member


@dataclass(frozen=True, slots=True)
class Material:
    name: str
    kind: str
    elastic_modulus: float
    shear_modulus: float
    poisson_ratio: float
    density: float


@dataclass(frozen=True, slots=True)
class Section:
    name: str
    material_kind: str
    family: str
    parameters: tuple[tuple[str, float], ...] = ()


@dataclass(frozen=True, slots=True)
class Action:
    name: str
    kind: str
    target: str
    components: tuple[float, ...]
    load_case: str


@dataclass(frozen=True, slots=True)
class ActionDefinition:
    """Nome legível e sigla usada nas combinações de ações."""

    name: str
    abbreviation: str


@dataclass(frozen=True, slots=True)
class ActionGroup:
    """Conjunto nomeado de ações disponíveis para um modelo."""

    name: str
    actions: tuple[ActionDefinition, ...] = ()


@dataclass(frozen=True, slots=True)
class LoadCase:
    name: str
    actions: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class LoadCombination:
    name: str
    factors: tuple[tuple[str, float], ...] = ()
    factors_2: tuple[tuple[str, float], ...] = ()
    factors_3: tuple[tuple[str, float], ...] = ()
    active_actions: tuple[str, ...] | None = None
    action_group: str | None = None
    limit_state: str = "CAR"


@dataclass(frozen=True, slots=True)
class AnalysisResult:
    model_revision: int
    load_reference: str
    node_results: dict[str, Any] = field(default_factory=dict)
    member_results: dict[str, Any] = field(default_factory=dict)
